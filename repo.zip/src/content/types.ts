export interface FishData {
  id: number;
  name: string;
  kgMin: number;
  kgMax: number;
  priceMin: number;
  priceMax: number;
}
export interface FishProduction {
  id: number;
  name: string;
  totalKg: number;
  price: number;
  monthlyKg: Record<number, number>;
}
export interface IWorkflowManager {
  stop(): void;
}
