(function(){"use strict";(function(){const f={init(e,t){let o=!1,s=0,r=0,i=0,d=0;t.addEventListener("mousedown",n=>{o=!0,s=n.clientX,r=n.clientY;const a=e.getBoundingClientRect();i=a.left,d=a.top,e.style.cursor="grabbing",n.preventDefault()}),globalThis.addEventListener("mousemove",n=>{o&&(e.style.left=`${i+(n.clientX-s)}px`,e.style.top=`${d+(n.clientY-r)}px`,e.style.bottom="auto",e.style.right="auto")}),globalThis.addEventListener("mouseup",()=>{o=!1,e.style.cursor="default"})}};function u(){if(document.getElementById("sigess-auto-reg-turbo"))return;const e=document.createElement("div");e.id="sigess-auto-reg-turbo",e.style.cssText=`
        position: fixed;
        bottom: 20px;
        left: 20px;
        width: 320px;
        z-index: 2147483647;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        background: rgba(15, 23, 42, 0.75);
        backdrop-filter: blur(16px) saturate(180%);
        -webkit-backdrop-filter: blur(16px) saturate(180%);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
        color: #f8fafc;
        overflow: hidden;
        user-select: none;
    `;const t=document.createElement("div");t.style.cssText=`
        padding: 10px 14px;
        background: rgba(255, 255, 255, 0.05);
        display: flex;
        align-items: center;
        justify-content: space-between;
        cursor: move;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    `,t.innerHTML=`
        <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 8px; height: 8px; background: #22c55e; border-radius: 50%; box-shadow: 0 0 8px #22c55e;"></div>
            <span style="font-size: 12px; font-weight: 700; letter-spacing: 0.5px; color: #10b981;">AUTO-REG TURBO</span>
        </div>
        <span style="font-size: 10px; color: #94a3b8; font-family: monospace;">v1.0.0-FLEX</span>
    `,e.appendChild(t);const o=document.createElement("div");o.style.padding="12px",o.style.display="flex",o.style.flexDirection="column",o.style.gap="10px";const s=document.createElement("div");s.style.display="grid",s.style.gridTemplateColumns="repeat(2, 1fr)",s.style.gap="6px",["MPA","eSocial","CadÚnico","TSE"].forEach(n=>{const a=document.createElement("div");a.id=`turbo-status-${n.toLowerCase().replace("ú","u")}`,a.style.cssText=`
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.05);
          border-radius: 6px;
          padding: 6px 8px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 10px;
          font-weight: 600;
      `,a.innerHTML=`<span>${n}</span> <span class="indicator" style="color: #64748b;">⏳</span>`,s.appendChild(a)}),o.appendChild(s);const i=document.createElement("div");i.id="turbo-log-terminal",i.style.cssText=`
        background: rgba(0, 0, 0, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 6px;
        height: 100px;
        overflow-y: auto;
        padding: 6px;
        font-family: 'JetBrains Mono', 'Fira Code', monospace;
        font-size: 10px;
        display: flex;
        flex-direction: column;
        gap: 2px;
    `,o.appendChild(i);const d=document.createElement("div");d.id="turbo-data-preview",d.style.cssText=`
        font-size: 11px;
        background: rgba(16, 185, 129, 0.1);
        border: 1px solid rgba(16, 185, 129, 0.2);
        border-radius: 8px;
        padding: 8px;
        display: none;
    `,o.appendChild(d),e.appendChild(o),document.body.appendChild(e),f.init(e,t),p("Sistema Turbo inicializado."),m()}function p(e,t="info"){const o=document.getElementById("turbo-log-terminal");if(!o)return;const s={info:"#cbd5e1",success:"#10b981",warn:"#f59e0b",error:"#ef4444"},r=document.createElement("div"),i=new Date().toLocaleTimeString([],{hour12:!1,hour:"2-digit",minute:"2-digit",second:"2-digit"});r.innerHTML=`<span style="color: #475569;">[${i}]</span> <span style="color: ${s[t]};">${e}</span>`,o.appendChild(r),o.scrollTop=o.scrollHeight}async function m(){const o=((await chrome.storage.local.get("sigessSettings")).sigessSettings||{}).pessoaData;o&&g(o)}function g(e){var r,i,d,n,a;const t=e.fontes||{},o={mpa:!!((r=t.pesqbrasil)!=null&&r.capturado),esocial:!!((i=t.caepf)!=null&&i.capturado),cadunico:!!((d=t.cadunico_adv)!=null&&d.capturado)||!!((n=t.cadunico)!=null&&n.capturado),tse:!!((a=t.tse)!=null&&a.capturado)};Object.entries(o).forEach(([h,v])=>{const l=document.getElementById(`turbo-status-${h}`);if(l){const b=l.querySelector(".indicator");v&&(b.innerText="✅",b.style.color="#10b981",l.style.background="rgba(16, 185, 129, 0.05)",l.style.borderColor="rgba(16, 185, 129, 0.2)")}});const s=document.getElementById("turbo-data-preview");s&&e.nome&&(s.style.display="block",s.innerHTML=`
        <div style="font-weight: 700; color: #10b981; margin-bottom: 4px;">Sócio Capturado:</div>
        <div style="font-size: 12px; font-weight: 600;">${e.nome}</div>
        <div style="color: #94a3b8; font-size: 10px; margin-top: 2px;">CPF: ${e.cpf||"---"} | RGP: ${e.rgp||"---"}</div>
      `)}globalThis.addEventListener("message",e=>{const{type:t}=(e==null?void 0:e.data)||{};t!=null&&t.startsWith("SIGESS_")}),globalThis.addEventListener("SIGESS_DEBUG_LOG",e=>{const{msg:t,type:o}=e.detail;p(t,o)}),chrome.storage.onChanged.addListener(e=>{if(e.sigessSettings){const t=e.sigessSettings.newValue||{};t.pessoaData&&(g(t.pessoaData),p("Banco de dados local atualizado.","success"))}});const c=globalThis.location.hostname,x=c.includes(".gov.br")||c.includes(".jus.br")||c.includes("mpa.gov.br"),y=c.includes("sigess");if(x||y){console.log("SIGESS: Auto-Reg Turbo script running on "+c);const e=()=>{if(!document.body){setTimeout(e,100);return}u(),new MutationObserver(()=>{document.getElementById("sigess-auto-reg-turbo")||u()}).observe(document.body,{childList:!0,subtree:!1})};document.readyState!=="loading"?e():globalThis.addEventListener("DOMContentLoaded",e)}})()})();
