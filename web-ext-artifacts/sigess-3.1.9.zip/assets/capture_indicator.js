(function(){"use strict";(function(){const n="sigess-capture-indicator";function r(){if(document.getElementById(n))return;const e=document.createElement("div");e.id=n,e.style.cssText=`
        position: fixed;
        bottom: 15px;
        left: 15px;
        z-index: 2147483647;
        padding: 6px 10px;
        background: rgba(15, 23, 42, 0.85);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 20px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        display: flex;
        align-items: center;
        gap: 8px;
        transition: transform 0.3s ease;
        pointer-events: auto;
    `;const t=document.createElement("span");t.style.cssText=`
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 10px;
        font-weight: 700;
        color: #94a3b8;
        letter-spacing: 0.5px;
        margin-right: 2px;
    `,t.innerText="SIGESS",e.appendChild(t);const s=document.createElement("div");s.style.cssText="display: flex; gap: 6px;",[{id:"cadunico",label:"CadÚnico"},{id:"tse",label:"TSE"},{id:"pesqbrasil",label:"PesqBrasil"},{id:"esocial",label:"CEI/CAEPF"},{id:"ecac",label:"e-CAC"}].forEach(o=>{const i=document.createElement("div");i.id=`sigess-dot-${o.id}`,i.title=o.label,i.style.cssText=`
          width: 8px;
          height: 8px;
          background: #334155;
          border-radius: 50%;
          transition: all 0.3s ease;
      `,s.appendChild(i)}),e.appendChild(s),document.body.appendChild(e),y()}function h(){const e=document.getElementById(n);e&&e.remove()}async function y(){const s=((await chrome.storage.local.get("sigessSettings")).sigessSettings||{}).pessoaData;d(s)}function d(e){var o,i,a,g,p,b,m,f,x;const t=(e==null?void 0:e.fontes)||{},s={cadunico:!!((o=t.cadunico)!=null&&o.capturado||(i=t.cadunico_adv)!=null&&i.capturado),tse:!!((a=t.tse)!=null&&a.capturado),pesqbrasil:!!((g=t.pesqbrasil)!=null&&g.capturado||(p=t.pesq_brasil)!=null&&p.capturado),esocial:!!((b=t.caepf)!=null&&b.capturado||(m=t.esocial)!=null&&m.capturado),ecac:!!((f=t.ecac_cpf)!=null&&f.capturado||(x=t.ecac_caepf)!=null&&x.capturado)};Object.entries(s).forEach(([E,S])=>{const c=document.getElementById(`sigess-dot-${E}`);c&&(S?(c.style.background="#10b981",c.style.boxShadow="0 0 6px #10b981"):(c.style.background="#334155",c.style.boxShadow="none"))});const l=document.getElementById(n);l&&(e!=null&&e.nome)&&(l.title=`Capturado: ${e.nome}`)}chrome.storage.onChanged.addListener(e=>{if(e.sigessSettings){const t=e.sigessSettings.newValue||{};t.autoRegistrationEnabled?globalThis.self===globalThis.top&&(r(),t.pessoaData&&d(t.pessoaData)):h()}});const u=async()=>{if(!((await chrome.storage.local.get("sigessSettings")).sigessSettings||{}).autoRegistrationEnabled)return;const s=globalThis.location.hostname;if((s.includes(".gov.br")||s.includes("mpa.gov.br")||s.includes("sigess"))&&document.body&&globalThis.self===globalThis.top){r();let o=null;new MutationObserver(()=>{o||(o=setTimeout(()=>{o=null,document.getElementById(n)||chrome.storage.local.get("sigessSettings").then(i=>{var a;(a=i.sigessSettings)!=null&&a.autoRegistrationEnabled&&r()})},300))}).observe(document.body,{childList:!0})}};document.readyState!=="loading"?u():document.addEventListener("DOMContentLoaded",u)})()})();
