var I=Object.defineProperty;var M=(c,p,f)=>p in c?I(c,p,{enumerable:!0,configurable:!0,writable:!0,value:f}):c[p]=f;var y=(c,p,f)=>M(c,typeof p!="symbol"?p+"":p,f);(function(){"use strict";const c=globalThis;typeof c.browser>"u"&&typeof c.chrome<"u"&&(c.browser=c.chrome),typeof c.browser<"u"&&!c.browser.action&&c.browser.browserAction&&(c.browser.action=c.browser.browserAction);function p(){return globalThis.browser!==void 0&&browser.storage?browser.storage.local:globalThis.chrome!==void 0&&chrome.storage?chrome.storage.local:null}class f{static async get(e){const t=p();return t?t.get(e):{}}static async set(e){const t=p();if(t)return t.set(e)}static async remove(e){const t=p();if(t)return t.remove(e)}static async getSettings(){const t=(await this.get("sigessSettings")).sigessSettings||{},i={consultarGuias:!1,gerarGps:!1,selectedYear:"current",selectedMonth:"08",valorComercializado:"",reapData:{2021:"",2022:"",2023:"",2024:""},mpaSpecies:[{id:12,kgMin:"60",kgMax:"70",priceMin:"8.00",priceMax:"11.00"},{id:21,kgMin:"55",kgMax:"60",priceMin:"8.00",priceMax:"12.00"},{id:26,kgMin:"55",kgMax:"60",priceMin:"9.00",priceMax:"13.00"},{id:25,kgMin:"55",kgMax:"60",priceMin:"10.00",priceMax:"13.00"},{id:15,kgMin:"45",kgMax:"50",priceMin:"13.00",priceMax:"16.00"}],mpaMascProdMin:"2850",mpaMascProdMax:"3075",mpaMascDaysMin:"125",mpaMascDaysMax:"135",mpaFemProdMin:"2550",mpaFemProdMax:"2850",mpaFemDaysMin:"118",mpaFemDaysMax:"124",autoRegistrationEnabled:!1,sdpaEnabled:!1,sdpaDefaultEmail:"",sdpaFallbackPhone:""};return{...i,...t,mpaSpecies:t.mpaSpecies&&t.mpaSpecies.length>0?t.mpaSpecies:i.mpaSpecies}}static async saveSettings(e){await this.set({sigessSettings:e})}static async mergePessoaData(e,t){const i=await this.getSettings(),s=i.pessoaData??{fontes:{}},r=i.pessoaData_raw??{},a={...e};a.cpf&&(a.cpf=a.cpf.toString().padStart(11,"0"));const n={...r,[t]:{...r[t]||{},...a}},l=["cadunico_adv","cadunico","pesqbrasil","pesq_brasil"];let o={nome:"",cpf:"",fontes:{...s.fontes||{}}};Object.entries(n).forEach(([u,m])=>{l.includes(u)||(o={...o,...m})}),[...l].reverse().forEach(u=>{n[u]&&(o={...o,...n[u]})}),o.fontes??(o.fontes={}),w(o,t,a);const h={...i,pessoaData:o,pessoaData_raw:n};return await this.saveSettings(h),h}static async getCredentials(e){const t=`credenciais_${e}`;return(await this.get(t))[t]||null}static async saveCredentials(e,t){const i=`credenciais_${e}`;await this.set({[i]:t})}static async clearCredentials(e){const t=`credenciais_${e}`;await this.remove(t)}}function w(b,e,t){b.fontes[e]={capturado:!0,timestamp:Date.now()},e.startsWith("cadunico")&&t.tituloEleitor&&t.zonaEleitoral&&t.secaoEleitoral&&(b.fontes.tse={capturado:!0,timestamp:Date.now()})}const g=class g{constructor(){y(this,"settings",null);y(this,"auditData",null);y(this,"auditIntervalId",null)}static async initialize(){g.instance||(g.instance=new g,window.addEventListener("hashchange",()=>{var e;return(e=g.instance)==null?void 0:e.handleRouteChange()}),window.addEventListener("popstate",()=>{var e;return(e=g.instance)==null?void 0:e.handleRouteChange()}),window.addEventListener("load",()=>{var e;return(e=g.instance)==null?void 0:e.handleRouteChange()})),await g.instance.handleRouteChange()}async handleRouteChange(){var t;if(this.settings=await f.getSettings(),!((t=this.settings)!=null&&t.sdpaEnabled)){this.stop();return}window.location.hash.includes("/solicitacao-pescador/etapas")?(this.auditData=this.settings.pessoaData||null,this.injectStyles(),this.injectUI(),this.startAuditor()):this.stop()}stop(){var e;this.auditIntervalId&&(clearInterval(this.auditIntervalId),this.auditIntervalId=null),(e=document.getElementById("sigess-sdpa-panel"))==null||e.remove()}injectStyles(){const e=document.createElement("style");e.textContent=`
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

      :root {
        --sigess-teal: #0f766e;
        --sigess-teal-dark: #0d9488;
        --sigess-amber: #f59e0b;
        --sigess-amber-dark: #d97706;
        --sigess-glass: rgba(255, 255, 255, 0.85);
        --sigess-border: rgba(226, 232, 240, 0.8);
      }

      .sigess-audit-green { border: 2px solid #10b981 !important; border-radius: 10px; padding: 3px; background: rgba(16, 185, 129, 0.04); }
      .sigess-audit-red { border: 2px solid #ef4444 !important; border-radius: 10px; padding: 3px; background: rgba(239, 68, 68, 0.04); }
      .sigess-audit-orange { border: 2px solid #f59e0b !important; border-radius: 10px; padding: 3px; background: rgba(245, 158, 11, 0.04); }
      
      .sigess-sdpa-panel {
        position: fixed;
        top: 16px;
        right: 16px;
        width: 180px;
        background: var(--sigess-glass);
        backdrop-filter: blur(16px) saturate(180%);
        -webkit-backdrop-filter: blur(16px) saturate(180%);
        border-radius: 12px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        z-index: 10000;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
        overflow: hidden;
        border: 1px solid var(--sigess-border);
        animation: sigess-slide-in 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        color: #1e293b;
      }

      @keyframes sigess-slide-in {
        from { transform: translateX(100%) opacity(0); }
        to { transform: translateX(0) opacity(1); }
      }
      
      .sigess-panel-header {
        background: linear-gradient(135deg, var(--sigess-teal) 0%, #134e4a 100%);
        padding: 8px 12px;
        display: flex;
        align-items: center;
        gap: 8px;
        border-bottom: 1px solid rgba(255,255,255,0.05);
      }

      .sigess-header-title {
        color: white;
        font-weight: 700;
        font-size: 11px;
        letter-spacing: -0.01em;
      }
      
      .sigess-panel-body { padding: 8px; display: flex; flex-direction: column; gap: 8px; }
      
      .sigess-data-card {
        background: rgba(255,255,255,0.4);
        border: 1px solid rgba(226, 232, 240, 0.3);
        border-radius: 6px;
        padding: 4px 6px;
        display: flex;
        flex-direction: column;
        gap: 1px;
        transition: all 0.2s ease;
      }

      .sigess-data-card:hover {
        background: white;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
      }

      .sigess-label {
        font-size: 8px;
        font-weight: 700;
        color: #64748b;
        text-transform: uppercase;
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .sigess-value {
        font-size: 10px;
        font-weight: 600;
        color: #1e293b;
        line-height: 1.2;
      }

      .sigess-btn-fill {
        width: 100%;
        padding: 8px;
        background: linear-gradient(135deg, var(--sigess-teal) 0%, var(--sigess-teal-dark) 100%);
        color: white;
        border: none;
        border-radius: 6px;
        font-weight: 700;
        font-size: 10px;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: 0 4px 12px rgba(15, 118, 110, 0.25);
      }

      .sigess-btn-fill:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(15, 118, 110, 0.35);
        filter: brightness(1.1);
      }

      .sigess-btn-fill:active {
        transform: translateY(0);
      }

      .sigess-icon-circle {
        background: rgba(15, 118, 110, 0.1);
        border-radius: 6px;
        padding: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
    `,document.head.appendChild(e)}startAuditor(){this.auditIntervalId&&clearInterval(this.auditIntervalId),this.auditIntervalId=setInterval(()=>{window.location.hash.includes("/solicitacao-pescador/etapas")?(document.getElementById("sigess-sdpa-panel")||this.injectUI(),(document.querySelector(".card-content")||document.querySelector(".br-card"))&&this.runAudit()):this.stop()},1500)}runAudit(){if(!this.auditData)return;document.querySelectorAll(".sigess-audit-green, .sigess-audit-red, .sigess-audit-orange").forEach(t=>t.classList.remove("sigess-audit-green","sigess-audit-red","sigess-audit-orange")),this.auditDateField();const e=this.auditData;this.auditTextField('input[name="endereco.cep"]',e.cep||""),this.auditTextField('input[name="endereco.logradouro"]',e.endereco||""),this.auditTextField('input[name="endereco.numero"]',e.numero||""),this.auditTextField('input[name="endereco.bairro"]',e.bairro||""),this.auditTextField('input[name="endereco.municipio"]',e.cidade||""),this.auditTextField('input[name="endereco.uf"]',e.uf||""),this.auditRadioRule("registroPesca.idAtividadePesqueira","Familiar"),this.auditRadioStatus("registroPesca.realizouContribuicao","Sim"),this.auditRadioStatus("registroPesca.possuiNotasFiscais","não"),this.auditRadioStatus("informarDadosBancarios","não"),this.validateSubmitButton()}applyAuditStyle(e,t){e&&(e.classList.remove("sigess-audit-green","sigess-audit-red","sigess-audit-orange"),t!=="none"&&e.classList.add(`sigess-audit-${t}`))}auditTextField(e,t){const i=document.querySelector(e);if(!i)return;const s=i.closest(".br-input")||i.parentElement;if(!s||!(s instanceof HTMLElement))return;const r=i.value.trim().toLowerCase(),a=(t||"").trim().toLowerCase();r===a&&r!==""?this.applyAuditStyle(s,"green"):a!==""?this.applyAuditStyle(s,"orange"):this.applyAuditStyle(s,"none")}getCPF(){var i,s;let e=((i=this.auditData)==null?void 0:i.cpf)||"";if(e.replaceAll(/\D/g,"").length===11)return e;const t=Array.from(document.querySelectorAll('[id^="campo-informacao-"]')).find(r=>{var n,l,o,d;const a=(d=(o=(l=(n=r.parentElement)==null?void 0:n.parentElement)==null?void 0:l.querySelector("div:first-child"))==null?void 0:o.textContent)==null?void 0:d.trim();return a==="Nome"||a==="CPF"});return t&&((s=t.textContent)==null?void 0:s.trim())||""}auditDateField(){const e=document.querySelector('input[placeholder="dd/mm/aaaa"]');if(!e||!this.auditData)return;const t=e.closest(".br-datetimepicker")||e.parentElement;if(!t||!(t instanceof HTMLElement))return;const i=e.value.trim(),s=this.auditData.dataPrimeiroRegistro||"",r=l=>{const o=l.replace(/\D/g,"");if(o.length!==8)return o;if(l.includes("-")){const[d,h,u]=l.split("-");return`${u}${h}${d}`}return o},a=r(i),n=r(s);a===n&&a!==""?this.applyAuditStyle(t,"green"):s!==""?this.applyAuditStyle(t,"orange"):this.applyAuditStyle(t,"none")}auditRadioRule(e,t){const i=document.querySelector(`input[id="${e}"]`);if(i){const s=i.closest(".br-select");s&&s instanceof HTMLElement&&(i.value.includes(t)?this.applyAuditStyle(s,"green"):this.applyAuditStyle(s,"red"))}}auditRadioStatus(e,t){var s,r;const i=document.querySelector(`input[name="${e}"]:checked`);if(i){const a=document.querySelector(`label[for="${i.id}"]`),n=(s=i.closest(".br-radio"))==null?void 0:s.parentElement;n&&n instanceof HTMLElement&&a&&((r=a.textContent)!=null&&r.toLowerCase().includes(t.toLowerCase())?this.applyAuditStyle(n,"green"):this.applyAuditStyle(n,"red"))}}validateSubmitButton(){const e=document.querySelector('button[type="submit"]');if(e){const t=document.querySelectorAll(".sigess-audit-red").length>0,i=e.parentElement;i&&(t?(i.style.border="4px solid #ef4444",i.style.borderRadius="8px"):(i.style.border="4px solid #10b981",i.style.borderRadius="8px"))}}mapEducationLevel(e){const t=e.toUpperCase().trim();return{"FUNDAMENTAL INCOMPLETO":"FUNDAMENTAL INCOMPL.","FUNDAMENTAL COMPLETO":"FUNDAMENTAL COMPLETO","MÉDIO INCOMPLETO":"ENS. MEDIO INCOMPL","MEDIO INCOMPLETO":"ENS. MEDIO INCOMPL","MÉDIO COMPLETO":"ENS. MEDIO COMPLETO","MEDIO COMPLETO":"ENS. MEDIO COMPLETO","SUPERIOR INCOMPLETO":"SUPERIOR INCOMPLETO","SUPERIOR COMPLETO":"SUPERIOR COMPLETO"}[t]||e}formatDateBR(e){if(!e)return"---";const t=e.replace(/\D/g,"");if(t.length===8){if(e.includes("-")){const[i,s,r]=e.split("-");return`${r}/${s}/${i}`}return`${t.substring(0,2)}/${t.substring(2,4)}/${t.substring(4)}`}return e}injectUI(){var s,r;if(document.getElementById("sigess-sdpa-panel"))return;const e=document.createElement("div");e.id="sigess-sdpa-panel",e.className="sigess-sdpa-panel";const t=this.formatDateBR((s=this.auditData)==null?void 0:s.dataPrimeiroRegistro),i=this.auditData?`${this.auditData.endereco||""}, ${this.auditData.numero||"S/N"} - ${this.auditData.bairro||""} (${this.auditData.cidade||""}/${this.auditData.uf||""})`.trim():"---";e.innerHTML=`
      <div class="sigess-panel-header">
        <div class="sigess-icon-circle" style="background: rgba(255,255,255,0.1)">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 8V4H8"></path><rect width="16" height="12" x="4" y="8" rx="2"></rect><path d="M2 14h2"></path><path d="M20 14h2"></path><path d="M15 13v2"></path><path d="M9 13v2"></path></svg>
        </div>
        <span class="sigess-header-title">Solicitação SDPA</span>
      </div>
      <div class="sigess-panel-body">
        <div class="sigess-data-card">
            <label class="sigess-label">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                Nome (Portal MTE)
            </label>
            <div id="sigess-fisherman-name" class="sigess-value">Extraindo nome...</div>
        </div>
        
        <div class="sigess-data-card">
            <label class="sigess-label">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                Data 1º Reg (SIGESS)
            </label>
            <div class="sigess-value">${t}</div>
        </div>

        <div class="sigess-data-card">
            <label class="sigess-label">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                Endereço (SIGESS)
            </label>
            <div class="sigess-value" style="font-size: 11px;">${i}</div>
        </div>

        <button class="sigess-btn-fill" id="sigess-btn-fill">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
            PREENCHER SDPA
        </button>
      </div>
    `,document.body.appendChild(e),setTimeout(()=>{var n;const a=Array.from(document.querySelectorAll('[id^="campo-informacao-"]')).find(l=>{var d,h,u,m;return((m=(u=(h=(d=l.parentElement)==null?void 0:d.parentElement)==null?void 0:h.querySelector("div:first-child"))==null?void 0:u.textContent)==null?void 0:m.trim())==="Nome"});if(a){const l=document.getElementById("sigess-fisherman-name");l&&(l.textContent=((n=a.textContent)==null?void 0:n.trim())||"---")}},2e3),(r=document.getElementById("sigess-btn-fill"))==null||r.addEventListener("click",()=>{this.runFiller().catch(a=>console.error("[SIGESS] SDPA Filler Error:",a))})}async runFiller(){var r,a;if(!this.auditData){alert("Dados de auditoria não encontrados. Abra novamente pelo SIGESS Web.");return}console.log("[SIGESS] Iniciando preenchimento SDPA..."),this.fillInput('input[name="contato.email"]',((r=this.settings)==null?void 0:r.sdpaDefaultEmail)||""),this.fillInput('input[name="contato.telefone"]',this.auditData.telefone||((a=this.settings)==null?void 0:a.sdpaFallbackPhone)||"");const e=this.mapEducationLevel(this.auditData.escolaridade||"");this.selectInBrSelect("grauInstrucao",e);const t=this.getCPF();if(t){const n=`PAPA${t.replaceAll(/\D/g,"")}`,l=Array.from(document.querySelectorAll("input")).find(o=>{var h,u,m,S,v,E;const d=((m=(u=(h=o.closest(".br-input"))==null?void 0:h.querySelector("label"))==null?void 0:u.textContent)==null?void 0:m.trim())||((E=(v=(S=o.parentElement)==null?void 0:S.querySelector("label"))==null?void 0:v.textContent)==null?void 0:E.trim());return d==null?void 0:d.includes("RGP")});l&&n!=="PAPA"&&(l.value=n,l.dispatchEvent(new Event("input",{bubbles:!0})))}const i=this.auditData;if(this.fillInput('input[name="endereco.cep"]',i.cep||""),this.fillInput('input[name="endereco.logradouro"]',i.endereco||""),this.fillInput('input[name="endereco.numero"]',i.numero||""),this.fillInput('input[name="endereco.complemento"]',""),this.fillInput('input[name="endereco.bairro"]',i.bairro||""),this.fillInput('input[name="endereco.municipio"]',i.cidade||""),this.fillInput('input[name="endereco.uf"]',i.uf||""),this.auditData.dataPrimeiroRegistro){const n=document.querySelector(".br-datetimepicker input");n&&n._flatpickr&&n._flatpickr.setDate(this.auditData.dataPrimeiroRegistro,!0,"d/m/Y")}this.selectInBrSelect("registroPesca.idAtividadePesqueira","Familiar"),this.clickRadio("registroPesca.realizouContribuicao","Sim"),this.clickRadio("registroPesca.possuiNotasFiscais","não"),this.clickRadio("informarDadosBancarios","não");const s=document.querySelector('input[name="aceiteRegras"]');s&&(s.checked=!0),setTimeout(()=>{this.selectInBrSelect("idDefeso","48")},1e3),setTimeout(()=>{var n;this.fillInput('input[name="endereco.cep"]',((n=this.auditData)==null?void 0:n.cep)||""),this.finalize()},2e3)}fillInput(e,t){const i=document.querySelector(e);i&&(i.value=t,i.dispatchEvent(new Event("input",{bubbles:!0})),i.dispatchEvent(new Event("change",{bubbles:!0})))}clickRadio(e,t){document.querySelectorAll(`input[name="${e}"]`).forEach(s=>{var a;const r=document.querySelector(`label[for="${s.id}"]`);(a=r==null?void 0:r.textContent)!=null&&a.toLowerCase().includes(t.toLowerCase())&&s.click()})}selectInBrSelect(e,t){var r;const i=`.br-select:has(#${CSS.escape(e)})`,s=document.querySelector(i);if(s){const a=s.querySelectorAll(".br-item label");for(const n of Array.from(a))if((r=n.textContent)!=null&&r.toUpperCase().includes(t.toUpperCase())){const l=n.getAttribute("for");if(l){const o=document.getElementById(l);o==null||o.click()}break}}}finalize(){var i;const e=((i=document.getElementById("sigess-fisherman-name"))==null?void 0:i.textContent)||"";e&&navigator.clipboard.writeText(e).catch(()=>{});const t=document.querySelector('input[type="file"]');t&&(t.style.display="block",t.style.width="100%",t.style.padding="20px",t.style.border="2px dashed #f59e0b",t.style.marginTop="10px",t.classList.add("sigess-flash-upload")),alert(`Preenchimento Concluído!

Nome copiado para o clipboard: ${e}

O campo de upload agora está visível em destaque.`)}};y(g,"instance",null);let x=g;document.location.href.includes("/solicitacao-pescador/etapas")&&(async()=>{try{await x.initialize()}catch(b){console.error("[SIGESS] SDPA Factory Error:",b)}})(),console.log("[SIGESS] SDPA Entry Point Active")})();
